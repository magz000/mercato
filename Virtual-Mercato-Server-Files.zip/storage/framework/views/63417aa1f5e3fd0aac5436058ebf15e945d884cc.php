<nav>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <h4 class="logo">Virtual Mercato</h4>
            </div>

            <div class="col-md-9" style="text-align: right;">
                <ul class="list-unstyled list-inline" style="margin-top: 10px;">
                    <?php if(!Auth::guard('p')->check()): ?>
                        <li><a href="#" data-toggle="modal" data-target="#_loginModal">Sign In</a></li>
                    <?php else: ?>
                        <li>
                            <div class="dropdown">
                                <div class=" dropdown-toggle" type="button" data-toggle="dropdown">
                                    <?php echo e(Auth::guard('p')->user()->firstname .  ' ' . Auth::guard('p')->user()->lastname); ?>

                                    <span class="caret"></span></div>
                                </button>

                                <ul class="dropdown-menu">
                                  <li><a href="<?php echo e(route('providerDashboardPage')); ?>"> <i class="fa fa-fw fa-dashboard"> </i> Dashboard</a></li>
                                  <li><a href="<?php echo e(route('providerOrderPage')); ?>"> <i class="fa fa-fw fa-list"> </i> Orders</a></li>
                                  <li><a href="<?php echo e(route('providerProductPage')); ?>"> <i class="fa fa-fw fa-cutlery"> </i> Products</a></li>
                                  <li><a href="<?php echo e(route('providerProfilePage')); ?>"> <i class="fa fa-fw fa-user"> </i> Profiles</a></li>
                                  <li><a href="<?php echo e(route('logoutProviderPage')); ?>"> <i class="fa fa-fw fa-sign-out"> </i> Logout</a></li>
                                </ul>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</nav>
