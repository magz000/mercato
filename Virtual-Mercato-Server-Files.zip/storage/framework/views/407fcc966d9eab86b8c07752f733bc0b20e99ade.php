<?php $__env->startSection('content'); ?>

        <?php $Product = app('App\Model\Product'); ?>
        <?php $Setting = app('App\Model\Setting'); ?>
        <?php $ProductCategory = app('App\Model\ProductCategory'); ?>
        <?php $Provider = app('App\Model\Provider'); ?>
        <?php $OrderRating = app('App\Model\OrderRating'); ?>

        <style media="screen">
            ul.dropdown-menu li {
                margin: 0px;
            }
        </style>

        <section class="__image-slider">
            <div class="__static-item">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="_searchForm">
                              <form action="<?php echo e(route('resultPage')); ?>" class="_form">
                                <input type="hidden" name="type" value="1">
                                <div class="form-group col-md-5">
                                  <label for="" class="pull-left">Product</label>
                                <div class="pull-right" style="margin-top: -2px; margin-bottom: 2px;">
                                    <span class="label label-primary __opt-categ" data-category="1" style="cursor: pointer">Search By Category</span>
                                    <span class="label label-default __opt-categ" data-category="2" style="cursor: pointer">Search Dishes</span>
                                </div>

                                <div class="clearfix"></div>
                                <div data-categ="1" class="__categ-failed">
                                    <select name="category" id="" class="form-control">
                                        <?php $__currentLoopData = $MainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <optgroup label="<?php echo e($category->name); ?>">
                                                <option value="<?php echo e($category->id); ?>">All <?php echo e($category->name); ?></option>
                                                <?php $__currentLoopData = $SubCategories($category->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($sub->id); ?>"><?php echo e($sub->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </optgroup>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div data-categ="2" class="__categ-failed" style="display: none;">
                                    <input type="text" class="form-control" name="product_name" placeholder="Search for a dish...">
                                </div>

                                </div>

                                <div class="form-group col-md-3">
                                  <div class="joined">
                                    <label for="">Date</label>
                                    <input id="date" type="text" class="form-control" name="date" placeholder="date" value="<?php echo e(date('Y-m-d')); ?>">
                                  </div>
                                  <div class="joined">
                                    <label for="">Time</label>
                                    <select name="time" id="" class="form-control">
                                        <option value="9:00 AM">9:00 AM</option>
                                    </select>
                                  </div>
                                </div>

                                <div class="form-group col-md-2">
                                  <label for="">Pick-up Station</label>
                                  <select name="location" id="" class="form-control">
                                    <option value="Katipunan">Katipunan</option>
                                    <option value="Cubao">Cubao</option>
                                    <option value="Marikina">Marikina</option>
                                  </select>
                                </div>

                                <div class="col-md-1">
                                  <button class="submit btn btn-primary btn-xl">Search</button>
                                </div>

                                <div class="clearfix"></div>
                              </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="__static-item">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <br/><br/>
                            <h2 class="logo">Virtual Mercato</h2>
                            <div class="clearfix"></div>
                            <small class="logo-by">by CCA</small>
                        </div>

                        <div class="col-md-9" style="text-align: right;">
                            <br/><br/>
                                <br/>
                            <ul class="list-unstyled list-inline" style="margin-top: 10px;">
                                <?php if(!Auth::guard('u')->check()): ?>
                                    <li><a href="#" data-toggle="modal" data-target="#_loginModal">Sign In</a></li>
                                    <li><a href="#" data-toggle="modal" data-target="#_SignUpModal">Sign Up</a></li>
                                <?php else: ?>
                                    <li>
                                        <div class="dropdown">
                                            <div class=" dropdown-toggle" type="button" data-toggle="dropdown">
                                                <?php echo e(Auth::guard('u')->user()->firstname .  ' ' . Auth::guard('u')->user()->lastname); ?>

                                                <span class="caret"></span></div>
                                            </button>

                                            <ul class="dropdown-menu">
                                              <li><a href="<?php echo e(route('userDashboardPage')); ?>">Dashboard</a></li>
                                              <li><a href="<?php echo e(route('userOrderPage')); ?>">Orders</a></li>
                                              <li><a href="<?php echo e(route('userProfilePage')); ?>">Profiles</a></li>
                                            </ul>


                                        </div>
                                    </li>
                                    <li><a href="#" data-toggle="modal" data-target="#__cartModal">Cart</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="__slider-item" style="background-image: url('https://images.unsplash.com/photo-1424847651672-bf20a4b0982b?auto=format&fit=crop&w=1350&q=60&ixid=dW5zcGxhc2guY29tOzs7Ozs%3D')"></div>
        </section>

        <div class="container __main-content">
            <div class="row">
                <div class="col-md-6 col-sm-6">
                    <h3 class="title white">Featured Chefs</h3>
                    <div class="__card padding">

                        <div id="myCarousel" class="carousel slide" data-ride="carousel"  data-interval="6000">


                          <!-- Wrapper for slides -->
                          <div class="carousel-inner">

                            <?php $__currentLoopData = $Setting->pull('featured_chefs', 'array'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php 
                                    $pr = $Provider->find($value);
                                 ?>
                                <div class="item <?php echo e($key == 0 ? 'active' : ''); ?>">
                                    <div class="row">
                                        <div class="col-md-4"><Br/>
                                            <center>
                                                <div class="avatar" style="background-image: url('<?php echo e(asset('img/providers/' . $pr->picture)); ?>');"></div>
                                                <br>

                                                <select class="example" readonly>
                                                    <?php for($i=1; $i <= 5; $i++): ?>
                                                        <option value="<?php echo e($i); ?>" <?php echo e($OrderRating->get_provider_rating($pr->id) == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                                    <?php endfor; ?>
                                                </select>
                                            </center>
                                        </div>

                                        <div class="col-md-8">
                                            <h2 class="pull-left"><?php echo e($pr->firstname . ' ' . $pr->lastname); ?></h2>
                                            <div class="pull-right" style="margin-top: 30px;"><a href="<?php echo e(route('userPage', $pr->username)); ?>"><span class="label label-primary">View Profile</span></a></div>
                                            <div class="clearfix"></div>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ullam accusantium rem excepturi, expedita nobis vitae.</p>
                                            <span class="label label-primary">Frozen</span> <span class="label label-primary">Cakes</span> <span class="label label-primary">Porks</span>
                                        </div>
                                    </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            <div class="clearfix"></div>
                          </div>
                          <br/>
                            <!-- Indicators -->
                            <ol class="carousel-indicators">
                                <?php for($i = 0; $i < count($Setting->pull('featured_chefs', 'array')); $i++): ?>
                                  <li data-target="#myCarousel" data-slide-to="<?php echo e($i); ?>" <?php echo $i == 0 ? 'class="active"' : ''; ?>></li>
                                <?php endfor; ?>
                            </ol>
                        </div>


                    </div>
                </div>
                <div class="col-md-6 col-sm-6">
                    <h3 class="title white">Featured Foods</h3>
                    <div class="__card">
                        <div id="foodCarousel" class="carousel slide" data-ride="carousel"  data-interval="5000">

                            <div class="clearfix"></div>
                              <!-- Indicators -->
                              <ol class="carousel-indicators">
                                  <?php for($i = 0; $i < count($Setting->pull('features_foods', 'array')); $i++): ?>
                                    <li data-target="#foodCarousel" data-slide-to="<?php echo e($i); ?>" <?php echo $i == 0 ? 'class="active"' : ''; ?>></li>
                                  <?php endfor; ?>
                              </ol>
                          <!-- Wrapper for slides -->
                          <div class="carousel-inner">
                            <?php $__currentLoopData = $Setting->pull('features_foods', 'array'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php 
                                    $pr = $Product->find($value);
                                 ?>

                                <div class="item <?php echo e($key == 0 ? 'active' : ''); ?>">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <center>
                                                <div class="food_avatar" style="background-image: url('<?php echo e(asset('img/uploads/' . $pr->picture)); ?>');"></div>
                                            </center>
                                        </div>

                                        <div class="col-md-8 padding-content">
                                            <h2><?php echo e($pr->name); ?></h2>
                                            <select class="example" readonly>
                                              <?php for($i=1; $i <= 5; $i++): ?>
                                                  <option value="<?php echo e($i); ?>" <?php echo e($OrderRating->get_rating($pr->id) == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                              <?php endfor; ?>
                                            </select>
                                            <p><?php echo e($pr->description); ?></p>
                                            <span class="label label-primary"><?php echo e($ProductCategory->find($pr->category_id)->name); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="clearfix"></div>
                          </div>


                        </div>

                    </div>
                </div>
            </div>

            <h3 class="title">Food Categories</h3>
            <div id="itemslide" class="row">
                    <?php $__currentLoopData = $MainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3">
                            <div class="__card full_bg" style="background-image: url('<?php echo e(asset('img/categories/' . $category->image)); ?>');">
                                <div class="inner"><p><?php echo e($category->name); ?></p></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>



        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>