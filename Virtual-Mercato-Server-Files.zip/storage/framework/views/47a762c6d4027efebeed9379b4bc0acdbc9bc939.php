<?php $__env->startSection('content'); ?>


     <?php echo $__env->make('layouts.public.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

     <div class="container">
         <Br/><Br/>
         <div class="col-md-3">
             <ul class="list-unstyled _dashboardMenu">
                 <li><a href="<?php echo e(route('userDashboardPage')); ?> "><i class="fa fa-fw fa-dashboard"> </i> Dashboard</a></li>
                 <li><a href="<?php echo e(route('userOrderPage')); ?> "><i class="fa fa-fw fa-list-alt"> </i> Orders</a></li>
                 <li><a href="<?php echo e(route('userDashboardPage')); ?> "><i class="fa fa-fw fa-star"> </i> My Ratings</a></li>
                 <li><a href="<?php echo e(route('userDashboardPage')); ?> "><i class="fa fa-fw fa-user"> </i> Profile</a></li>
             </ul>
         </div>
     </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>