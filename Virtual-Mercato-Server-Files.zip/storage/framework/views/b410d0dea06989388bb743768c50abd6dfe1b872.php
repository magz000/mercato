<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.providers.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php $OrderContentModel = app('App\Model\OrderContent'); ?>
    <?php $OrderModel = app('App\Model\Order'); ?>
    <?php $ProductModel = app('App\Model\Product'); ?>
    <?php $ProviderModel = app('App\Model\Provider'); ?>
    <?php $OrderRatingModel = app('App\Model\OrderRating'); ?>


    <div class="container">

        <style media="screen">
            td {
                border-top: none !important;
            }


        </style>

        <br><br><br>

        <div class="row">

            <?php echo $__env->make('layouts.providers.side_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="col-md-10">
                <?php $__currentLoopData = $order_ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                        $order = $OrderModel->find($order_id);
                        $contents = $OrderContentModel->where('order_id', '=', $order_id)->where('provider_id', '=', Auth::guard('p')->user()->id)->get();
                     ?>

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <div class="pull-left small"><?php echo e($order->firstname . ' ' . $order->lastname); ?></div>
                            <div class="pull-right small"><span class="label label-<?php echo e($OrderModel->state($order->status)['state']); ?>"><?php echo e($OrderModel->state($order->status)['value']); ?></span></div>
                            <div class="clearfix"></div>
                        </div>

                        <div class="panel-body">
                            <table class="table small">
                                <thead  style="border-bottom: 1px solid #ddd;">
                                    <th></th>
                                    <th>Product</th>
                                    <th>Qty</th>
                                    <th>Price</th>
                                    <th>Total</th>
                                    <th>Pickup Date & Time</th>
                                    <th>Pikcup Location</th>
                                    <th>Status</th>
                                    <th>Note</th>
                                    <th>Option</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($OrderContentModel->expire($content) ? '' : ''); ?>

                                        <tr>
                                            <td><div class="avatar med" style="background-image: url('<?php echo e(asset('img/uploads/' . $ProductModel->find($content->product_id)->picture)); ?>')"></div></td>
                                            <td>
                                                <?php echo e($ProductModel->find($content->product_id)->name); ?><br/>
                                                Served By : <a href="<?php echo e(route('userPage', $ProviderModel->find($content->provider_id)->username)); ?>"><?php echo e($ProviderModel->find($content->provider_id)->firstname . ' ' . $ProviderModel->find($content->provider_id)->lastname); ?></a>
                                            </td>
                                            <td><?php echo e($content->quantity); ?></td>
                                            <td>PHP <?php echo e(number_format($content->price, 2)); ?></td>
                                            <td>PHP <?php echo e(number_format($content->total, 2)); ?></td>
                                            <td><?php echo e(date('M d, Y', strtotime($content->pickup_date)) . ' ' . $content->pickup_time); ?></td>
                                            <td><?php echo e($content->pickup_location); ?></td>
                                            <td><span class="label label-<?php echo e($OrderContentModel->state($content->status)['state']); ?>"><?php echo e($OrderContentModel->state($content->status)['value']); ?></span></td>
                                            <td><button type="button" data-toggle="tooltip" title="<?php echo e($content->note); ?>" class="btn btn-default btn-xs"><i class="fa fa-fw fa-eye"> </i></button></td>
                                            <td>
                                                <?php if($content->status < 3): ?>
                                                    <button type="button"  class="btn btn-default btn-xs __updateTrigger" data-ocid="<?php echo e($content->id); ?>" data-status="<?php echo e($content->status); ?>" data-toggle="modal" data-target="#__updateOrder"><i class="fa fa-fw fa-pencil"> </i></button>
                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td colspan="10" style="border-bottom: 1px solid #ddd;">
                                                <?php if($content->status == 3 && $OrderRatingModel->is_rated($content->id) == null): ?>

                                                <?php endif; ?>

                                                <?php if($OrderRatingModel->is_rated($content->id) != null): ?>
                                                    <?php 
                                                        $rating = $OrderRatingModel->where('content_id', '=', $content->id)->get()->first();
                                                     ?>

                                                    <div class="row">
                                                        <div class="col-md-3">
                                                            <center>
                                                                <select class="__rating_selected">
                                                                  <option value="1" <?php echo e($rating->value == 1 ? 'selected' : ''); ?> data-html="Very Good">1</option>
                                                                  <option value="2" <?php echo e($rating->value == 2 ? 'selected' : ''); ?> data-html="Good">2</option>
                                                                  <option value="3" <?php echo e($rating->value == 3 ? 'selected' : ''); ?> data-html="Average">3</option>
                                                                  <option value="4" <?php echo e($rating->value == 4 ? 'selected' : ''); ?> data-html="Poor">4</option>
                                                                  <option value="5" <?php echo e($rating->value == 5 ? 'selected' : ''); ?> data-html="Very Poor">5</option>
                                                                </select>
                                                            </center>
                                                        </div>

                                                        <div class="col-md-9">
                                                            <div class="form-group">
                                                                <?php echo e($rating->message); ?>

                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div id="__updateOrder" class="modal fade" role="dialog">
      <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Update Order Status</h4>
          </div>
          <div class="modal-body">
              <div class="form-group">
                  <label for="">Status</label>
                  <input type="hidden" name="content_id" value="">
                  <select name="content_status" id="" class="form-control">
                      <option value="0">Pending</option>
                      <option value="1">Cooking</option>
                      <option value="2">Ready for Pickup</option>
                  </select>

              </div>
          </div>
          <div class="modal-footer">
            <button type="button" id="__updateOrderBtn" class="btn btn-success" data-dismiss="modal">Update Order</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>

      </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(function() {

            $('#__updateOrderBtn').click(function() {
                $(this).attr('disabled', 'disabled').html('<i class="fa fa-refresh  fa-spin fa-fw"></i> Saving...');
                $.ajax({
                    url: '<?php echo e(route('order.content.update')); ?>',
                    method : 'POST',
                    data : {content_id : $('input[name="content_id"]').val(), status : $('select[name="content_status"]').val()},
                    headers: {
                        'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(data) {
                        if(data == "1") {
                            location.reload();
                        }
                    }
                });
            });

            $('.__updateTrigger').click(function() {
                var ocid = $(this).attr('data-ocid');
                $('input[name="content_id"]').val(ocid);
                $('select[name="content_status"]').val($(this).attr('data-status'));
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>