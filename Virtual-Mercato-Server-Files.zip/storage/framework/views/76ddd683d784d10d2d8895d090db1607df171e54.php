<?php $__env->startSection('content'); ?>


     <?php echo $__env->make('layouts.public.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

     <div class="container">
         <Br/><Br/>
         <div class="col-md-2">
             <ul class="list-unstyled _dashboardMenu">
                 <li><a href="<?php echo e(route('userDashboardPage')); ?> "><i class="fa fa-fw fa-dashboard"> </i> Dashboard</a></li>
                 <li><a href="<?php echo e(route('userOrderPage')); ?> "><i class="fa fa-fw fa-list-alt"> </i> Orders</a></li>
                 <li><a href="<?php echo e(route('userDashboardPage')); ?> "><i class="fa fa-fw fa-star"> </i> My Ratings</a></li>
                 <li><a href="<?php echo e(route('userDashboardPage')); ?> "><i class="fa fa-fw fa-user"> </i> Profile</a></li>
             </ul>
         </div>

         <div class="col-md-10">
             <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="panel panel-default">
                     <div class="panel-heading">
                         <div class="pull-left">
                             <?php echo e($order->firstname . ' ' . $order->lastname); ?>

                         </div>

                         <div class="pull-right">
                             <h3 style="margin: 0;"><?php echo e(number_format($order->total, 2)); ?></h3>
                             <?php 
                                 print_r($status($order->status));
                              ?>
                         </div>

                         <div class="clearfix"></div>
                     </div>
                 </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </div>
     </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>