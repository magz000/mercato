<?php 
use App\Model\OrderRating;
use App\Model\OrderContent;
use App\Model\Order;
use App\Model\Product;
use App\Model\Provider;
 ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.public.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <style media="screen">
        td {
            border-top: none !important;
        }
    </style>

    <div class="container">
        <br/><Br/><br/>
        <div class="row">

            <?php echo $__env->make('layouts.users.side_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="col-md-10">

                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <div class="pull-left small"><?php echo e($order->firstname . ' ' . $order->lastname); ?></div>
                            <div class="pull-right small"><span class="label label-<?php echo e(Order::state($order->status)['state']); ?>"><?php echo e(Order::state($order->status)['value']); ?></span></div>
                            <div class="clearfix"></div>
                        </div>

                        <div class="panel-body">
                            <form class="" action="<?php echo e(route('userRatingProcess', [$order->id, $order->user_id, md5($order->id . 'cmplx' . $order->user_id)])); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <table class="table small">
                                    <thead  style="border-bottom: 1px solid #ddd;">
                                        <th></th>
                                        <th>Product</th>
                                        <th>Qty</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                        <th>Pickup Date & Time</th>
                                        <th>Pikcup Location</th>
                                        <th>Status</th>
                                        <th>Note</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $contents($order->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e(OrderContent::expire($content) ? '' : ''); ?>

                                            <tr>
                                                <td><div class="avatar med" style="background-image: url('<?php echo e(asset('img/uploads/' . Product::find($content->product_id)->picture)); ?>')"></div></td>
                                                <td>
                                                    <?php echo e(Product::find($content->product_id)->name); ?><br/>
                                                    Served By : <a href="<?php echo e(route('userPage', Provider::find($content->provider_id)->username)); ?>"><?php echo e(Provider::find($content->provider_id)->firstname . ' ' . Provider::find($content->provider_id)->lastname); ?></a>
                                                </td>
                                                <td><?php echo e($content->quantity); ?></td>
                                                <td>PHP <?php echo e(number_format($content->price, 2)); ?></td>
                                                <td>PHP <?php echo e(number_format($content->total, 2)); ?></td>
                                                <td><?php echo e(date('M d, Y', strtotime($content->pickup_date)) . ' ' . $content->pickup_time); ?></td>
                                                <td><?php echo e($content->pickup_location); ?></td>
                                                <td><span class="label label-<?php echo e(OrderContent::state($content->status)['state']); ?>"><?php echo e(OrderContent::state($content->status)['value']); ?></span></td>
                                                <td><button type="button" data-toggle="tooltip" title="<?php echo e($content->note); ?>" class="btn btn-default btn-xs"><i class="fa fa-fw fa-eye"> </i></button></td>
                                            </tr>

                                            <tr>
                                                <td colspan="9" style="border-bottom: 1px solid #ddd;">
                                                    <?php if($content->status == 3 && OrderRating::is_rated($content->id) == null): ?>
                                                        <input type="hidden" name="ocid[]" value="<?php echo e($content->id); ?>">

                                                        <label for="" class="small">What do you think about the food?</label>
                                                        <div class="row">
                                                            <div class="col-md-3">
                                                                <Br/>
                                                                <center>
                                                                    <select name="rating__<?php echo e($content->id); ?>" class="__rating">
                                                                      <option value="1" data-html="Very Good">1</option>
                                                                      <option value="2" data-html="Good">2</option>
                                                                      <option value="3" data-html="Average">3</option>
                                                                      <option value="4" data-html="Poor">4</option>
                                                                      <option value="5" data-html="Very Poor">5</option>
                                                                    </select>
                                                                </center>
                                                            </div>

                                                            <div class="col-md-9">
                                                                <div class="form-group">
                                                                    <textarea name="message__<?php echo e($content->id); ?>" id="" cols="30" class="form-control" placeholder="Message"></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>

                                                    <?php if(OrderRating::is_rated($content->id) != null): ?>
                                                        <?php 
                                                            $rating = OrderRating::where('content_id', '=', $content->id)->get()->first();
                                                         ?>
                                                        <label for="" class="small">What do you think about the food?</label>
                                                        <div class="row">
                                                            <div class="col-md-3">
                                                                <center>
                                                                    <select class="__rating_selected">
                                                                      <option value="1" <?php echo e($rating->value == 1 ? 'selected' : ''); ?> data-html="Very Good">1</option>
                                                                      <option value="2" <?php echo e($rating->value == 2 ? 'selected' : ''); ?> data-html="Good">2</option>
                                                                      <option value="3" <?php echo e($rating->value == 3 ? 'selected' : ''); ?> data-html="Average">3</option>
                                                                      <option value="4" <?php echo e($rating->value == 4 ? 'selected' : ''); ?> data-html="Poor">4</option>
                                                                      <option value="5" <?php echo e($rating->value == 5 ? 'selected' : ''); ?> data-html="Very Poor">5</option>
                                                                    </select>
                                                                </center>
                                                            </div>

                                                            <div class="col-md-9">
                                                                <div class="form-group">
                                                                    <?php echo e($rating->message); ?>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                                <div class="row">
                                    <div class="col-md-9">
                                        <?php if(OrderContent::rating($order->id) && !OrderRating::all_rated($contents($order->id))): ?>
                                            <button class="btn btn-success btn lg">Submit Rating</button>
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="pull-right" style="text-align: right;">
                                            <small>PHP</small>
                                            <h3 style="margin-top: -5px;"><small style="font-size: 12px;">Order Total </small> <?php echo e(number_format($order->total, 2)); ?></h3>
                                            <small>PHP</small>
                                            <h3 style="margin-top: -5px;"><small style="font-size: 12px;">Service Charge </small> <?php echo e(number_format($order->service_charge, 2)); ?></h3>
                                            <small>PHP</small>
                                            <h3 style="margin-top: -5px;"><small style="font-size: 12px;">Grand Total </small> <?php echo e(number_format($order->total + $order->service_charge, 2)); ?></h3>
                                        </div>
                                    </div>
                                </div>
                            </form>

                            <div class="clearfix"></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>