<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    //
}
