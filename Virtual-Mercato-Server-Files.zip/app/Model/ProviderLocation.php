<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class ProviderLocation extends Model
{
    protected $table = 'provider_locations';
}
