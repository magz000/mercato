<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use App\Model\AuditTrail;
use App\Model\Order;
use App\Model\OrderContent;
use App\Model\OrderTransaction;
use App\Model\Provider;
use App\Model\Product;
use App\Model\ProductCategory;
use App\Model\PageView;
use App\Model\OrderRating;

class Reports extends Model
{

}
