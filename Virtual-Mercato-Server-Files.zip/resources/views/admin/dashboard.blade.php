@extends('layouts.admin.layouts')

@section('content')
    @include('layouts.admin.navigation')

    <div class="container">
        <div class="row">

            @include('layouts.admin.side_nav')

            <div class="col-md-10">

            </div>
        </div>
    </div>
@endsection
