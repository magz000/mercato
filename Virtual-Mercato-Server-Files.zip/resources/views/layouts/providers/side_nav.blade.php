<div class="col-md-2">
    <ul class="list-unstyled __dashboardMenu">
        <li><a href="{{ route('providerDashboardPage') }}"> <i class="fa fa-fw fa-dashboard"> </i> Dashboard</a></li>
        <li><a href="{{ route('providerOrderPage') }}"> <i class="fa fa-fw fa-list"> </i> Orders</a></li>
        <li><a href="{{ route('providerProductPage') }}"> <i class="fa fa-fw fa-cutlery"> </i> Products</a></li>
        <li><a href="{{ route('providerProfilePage') }}"> <i class="fa fa-fw fa-user"> </i> Profiles</a></li>
        <li><a href="{{ route('logoutProviderPage') }}"> <i class="fa fa-fw fa-sign-out"> </i> Logout</a></li>
    </ul>
</div>
