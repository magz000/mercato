
<div class="col-md-2">
    <ul class="list-unstyled __dashboardMenu">
        <li><a href="{{ route('userDashboardPage') }}"> <i class="fa fa-fw fa-dashboard"> </i> Dashboard</a></li>
        <li><a href="{{ route('userOrderPage') }}"> <i class="fa fa-fw fa-list"> </i> Orders</a></li>
        <li><a href="{{ route('userProfilePage') }}"> <i class="fa fa-fw fa-user"> </i> Profiles</a></li>
        <li><a href="{{ route('logoutUserPage') }}"> <i class="fa fa-fw fa-sign-out"> </i> Logout</a></li>
    </ul>
</div>
