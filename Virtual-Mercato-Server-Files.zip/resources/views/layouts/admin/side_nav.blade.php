<div class="col-md-2">
    <ul class="list-unstyled __dashboardMenu">
        <li><a href="{{ route('admin.dashboard') }}"> <i class="fa fa-fw fa-dashboard"> </i> Dashboard</a></li>
        <li><a href="{{ route('admin.orders') }}"> <i class="fa fa-fw fa-list"> </i> Orders</a></li>
        <li><a href="{{ route('admin.providers') }}"> <i class="fa fa-fw fa-cutlery"> </i> Providers</a></li>
        <li><a href="{{ route('admin.clients') }}"> <i class="fa fa-fw fa-users"> </i> Clients</a></li>
        <li><a href="{{ route('admin.clients') }}"> <i class="fa fa-fw fa-tags"> </i> Categories</a></li>
        <li><a href="{{ route('admin.clients') }}"> <i class="fa fa-fw fa-map-marker"> </i> Locations</a></li>
        <li><a href="{{ route('admin.profile') }}"> <i class="fa fa-fw fa-user"> </i> Profiles</a></li>
    </ul>
</div>
